#!/bin/bash
set -x

git submodule init
git submodule update
